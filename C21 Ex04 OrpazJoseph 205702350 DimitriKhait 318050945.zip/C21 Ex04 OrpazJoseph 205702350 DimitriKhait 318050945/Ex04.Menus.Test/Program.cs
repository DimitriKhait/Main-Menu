﻿namespace Ex04.Menus.Test
{
    public class Program
    {
        public static void Main()
        {
            new HandleInterface().Handle();

            new HandleDelegates().Handle();
        }
    }
}
