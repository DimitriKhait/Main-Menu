﻿namespace Ex04.Menus.Interfaces
{
    public interface IMenu
    {
        string MenuBuilder();
    }
}
