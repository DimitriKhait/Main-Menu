﻿namespace Ex04.Menus.Interfaces
{
    public interface ITask
    {
        void TaskToDo();
    }
}
