﻿namespace Ex04.Menus.Interfaces
{
    public interface IHandleTask
    {
        void HandleTask(ITask i_Task);
    }
}